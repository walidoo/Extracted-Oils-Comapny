/*
Navicat MySQL Data Transfer

Source Server         : My DataBase
Source Server Version : 50620
Source Host           : localhost:3306
Source Database       : extractoils

Target Server Type    : MYSQL
Target Server Version : 50620
File Encoding         : 65001

Date: 2015-09-06 22:28:21
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `events`
-- ----------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `img` varchar(300) NOT NULL,
  `details` varchar(300) NOT NULL,
  `link` varchar(300) NOT NULL DEFAULT '#',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of events
-- ----------------------------
INSERT INTO events VALUES ('1', 'Event 1', 'images/teams/1.jpg', 'Mr. Major General Staff Of The War Ibrahim Hassanein Visit The Company Was Received By Engineer / Mohamed Nabil President Of The Company And Senior Company Officials at  3/8/2015', '#');
INSERT INTO events VALUES ('2', 'Event 2', 'images/teams/2.jpg', 'The minister of supplies and internal trades Dr/ Khalid Hanafy had visited the extractedoils&derivatives co. at24/1/2015 also at 24/5/2014', 'https://youtu.be/LbLWRbrtt3I');
INSERT INTO events VALUES ('3', 'Event 3', 'images/teams/3.jpg', 'Addis Ababa, Ethiopia, the international exhibition from 19: February 25, 2015 has represented the company of Mr. Accountant / Omar Saud  financial Managing Director accompanied by Egyptian Ambassador', '#');
INSERT INTO events VALUES ('4', 'Event 4', 'images/teams/4.jpg', 'Khartoum International Fair in Sudan in the period from 21:28 Jan  2015 represents the company\'s Engineer / Ibrahim Khattab  accompanied by Dr / Salah Eddin Helal, Minister of Agriculture', '#');
INSERT INTO events VALUES ('5', 'Event 5', 'images/teams/5.jpg', 'Mr. Eng / Prime Minister Ibrahim Mahlab, Industry Minister Mounir Fakhry Abdelnour with Head of  Marketing Sector  Mr. / Fahmy Zaki Gomaa at the Cairo International Fair', '#');
INSERT INTO events VALUES ('6', 'Event 6', 'images/teams/6.jpg', 'The company jointly at the Cairo International Fair was Dr. Salah Eddin Helal, Minister of agreculture   attended have expressed  applauded the company\'s products from oils, detergents and soap  eng. Mohamed Nabil  Atia head chairman of the board', '#');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `product_name` varchar(300) DEFAULT NULL,
  `message` varchar(300) DEFAULT NULL,
  `phone` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO orders VALUES ('1', 'walid', 'walidjuba@gmail.com', 'product', 'welcome product 2', '1271015534');
INSERT INTO orders VALUES ('2', 'walid', 'walidjuba@gmail.com', '', '', '1271015534');

-- ----------------------------
-- Table structure for `products`
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) DEFAULT NULL,
  `product_desc` varchar(300) DEFAULT NULL,
  `product_img` varchar(300) DEFAULT NULL,
  `product_quantity` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO products VALUES ('1', 'Mira', 'It \'s light yellow oil </br> It contains unsaturated fatty acids which reduce the cholesterol rate in blood . </br> It contains vitamine (H) which is a natural antioxidant.  ', 'images/portfolio/oils/91.jpg', '¾L , 1L , 2L , 3L', 'oils');
INSERT INTO products VALUES ('2', 'Al Fayrouz', 'It contains a high percentage of fatty acid , (Omega) , Linolenic acid & Linoleic acid . </br> Which are very important due to the inability of the human   body of producing them. </br> Unsaturated fatty acids reduce cholesterol rate in blood.', 'images/portfolio/oils/92.jpg', '¾L', 'oils');
INSERT INTO products VALUES ('3', 'AL Safa', 'It is golden light yellow. Its has a distinguished flower, and taste. </br> It contains unsaturated fatty acids which reduce the cholesterol rate in blood . </br> It contains vitamin (H) which is a natural antioxidant .', 'images/portfolio/oils/93.jpg', ' ¾L , 1L , 3L ', 'oils');
INSERT INTO products VALUES ('4', 'Faransawy', ' It has a well balanced compactions of fatty acids which makes it light in digestion & reduce the cholesterol rate in blood. </br> It’s the best art of oils for frying.', 'images/portfolio/oils/Fr.jpg', '¾L, 1L', 'oils');
INSERT INTO products VALUES ('5', 'Mixola', 'Blended oils for frying purposes', 'images/portfolio/No-Image.jpg', '1 L, 3L ', 'oils');
INSERT INTO products VALUES ('6', 'AL Marwa', 'Blended oils for frying purposes', 'images/portfolio/No-Image.jpg', '¾ L, 1L', 'oils');
INSERT INTO products VALUES ('7', 'Marmoura', 'Blended oils for frying purposes', 'images/portfolio/oils/031.jpg', '¾ L, 1L', 'oils');
INSERT INTO products VALUES ('8', 'Fine el Nakhil', null, 'images/portfolio/ghee/fine.jpg', '2kg, 3kg, 5kg, &12kg', 'ghee');
INSERT INTO products VALUES ('9', 'HANYA ', null, 'images/portfolio/ghee/hanya.jpg', '1kg , 2kg, 5kg, & 15kg', 'ghee');
INSERT INTO products VALUES ('10', 'FINE ELNAKHIL', null, 'images/portfolio/shorting& Margraine/finee.jpg', '4kg , 5kg , 8kg , & 10kg', 'shorting&margraine');
INSERT INTO products VALUES ('11', 'GOLDEN ', 'One of the best products manufactured of the natural vegetable oils suitable for all cooking purposes .', 'images/portfolio/shorting& Margraine/mar.jpg', '900gm', 'shorting&margraine');
INSERT INTO products VALUES ('12', 'MARGRINE', 'Emulsion manufactured of the highest qualities,and purest vegetable oils. It contains natural emulsifiers , flavours & colours. It\'s butter subtitute ', 'images/portfolio/No-Image.jpg', '1KG', 'shorting&margraine');
INSERT INTO products VALUES ('13', 'LECITHIN ', 'Its colour is between light yellow , & brown. </br> Its fragrance is light & distinguished . </br> Can centration ( is not less than ) 60% min.  </br> Acid value is 36 max. </br> It is used as emulsifiers in the ( industry ) production of margarine , choclotes , & biscuits.', 'images/portfolio/No-Image.jpg', null, 'shorting&margraine');
INSERT INTO products VALUES ('14', 'Toilt Soap', 'Has a soft textufe with hugh foam .', 'images/portfolio/No-Image.jpg', null, 'soaps&clyeerine');
INSERT INTO products VALUES ('15', 'Pensée', 'White , flower fragrance . </br> Yellow , fruits fragrance . </br> Honey , Bee honey fragrance . </br> Rose,attractive french fragrance .', 'images/portfolio/Soaps&Clyeerine/pe.jpg', '120 gm', 'soaps&clyeerine');
INSERT INTO products VALUES ('16', 'Oliva', 'Green, oliva oiol fragrance . </br> Honey , honey fragrance . </br> Blue , Jasmine fragrance . </br> Rose , Bunch of flowers fragrance .', 'images/portfolio/Soaps&Clyeerine/olee.jpg', '75gm , 85gm , &140 gm', 'soaps&clyeerine');
INSERT INTO products VALUES ('17', 'Rosa', 'contains skin moisturing matrials </br> has 3 colours : Red , Spring breeze fragrance .', 'images/portfolio/Soaps&Clyeerine/ros.jpg', '75gm', 'soaps&clyeerine');
INSERT INTO products VALUES ('18', 'Laundry Soap ', 'Homogeneous , free of any off odours . It produces dense and soft foam , and has a long shelf life .', 'images/portfolio/Soaps&Clyeerine/xe.jpg', 'Domino : 140gm , 160gm & 200 gm </br> Diana : 400 gm , Lion 200 gm.', 'soaps&clyeerine');
INSERT INTO products VALUES ('19', 'Glycerol', 'Crude Glycerol . </br> Distilled Glycerol : It has a wide range os medical ,& pharmaceutial applications . </br> Concentration not less than 99% . </br> Relative density : 1.260 - 1.264 . </br> Concentrated glycerol not less than 80% .', 'images/portfolio/No-Image.jpg', null, 'soaps&clyeerine');
INSERT INTO products VALUES ('20', 'Hattric ', 'Low foam detergent powder  </br> Hattric 160 gm in bags. </br> Hattric 160 gm in bags.', 'images/portfolio/Powder_Detergents/x1.jpg', '1 kg , 5kg ', 'powder detergents');
INSERT INTO products VALUES ('21', 'Hattric ', ' High foam detergent powder  ', 'images/portfolio/Powder_Detergents/x2.jpg', 'Hattric : bags : 45 gm ,100gm , 200 gm , 500 gm  </br> Cartons: 100 gm , 125gm , 150 gm , 200 gm , 500 gm . 1 kg </br> Sacks : 3kg , 10 kg </br> Joker bags : 170gm  </br> sacks : 12.250 kg', 'powder detergents');
INSERT INTO products VALUES ('22', 'Hattric Specifications', 'Hattric depends not only on the active matter in removing dirts but also on other active materials of effective cleaning power in removing spots and dirts from laundry . </br> It contains vital materials specifying in removing fatty spots . </br> Friend of environment .', 'images/portfolio/Powder_Detergents/x4.jpg', null, 'powder detergents');
INSERT INTO products VALUES ('23', ' Sulphonic Acid', 'Active matter is 95 % min . </br> Density is between 1.04 : 1.08 at 20°C . </br> It\'s used in manufacturing the anionic . </br> Surfactant baseused in detergent industry .', 'images/portfolio/Powder_Detergents/x3.jpg', null, 'powder detergents');
INSERT INTO products VALUES ('24', 'Liquid Sodium Silicate', 'It\'s a thick , semi - transparent , colorless concentration : 40% : 42% . </br> It\'s used for general purposes : The industry of detergents , ceramics , metals and adhesive materials .', 'images/portfolio/No-Image.jpg', null, 'powder detergents');
INSERT INTO products VALUES ('25', 'Hattric ', 'in P.E.T Bottles </br> Green, Lemon fragrance . </br> Red , Apple fragrance . </br> Orange, Orange fragrance. </br> Scarlet , Peach fragrance .', 'images/portfolio/Liquids&Detergents/3.jpg', '¾ L : 4 COLOURS', 'liquids detergents');
INSERT INTO products VALUES ('26', 'Hattric ', 'It is suitable for all household purposes .      \r\nIt contains active matter capable of eliminating bactiria .\r\nHATTRIC 4L . : liquid detergent, germs killer .  </br> in P.E.T Bottles </br> Green, Lemon fragrance . </br> Red , Apple fragrance . </br> Orange, Orange fragrance. </br> Scarlet , Peach f', 'images/portfolio/Liquids&Detergents/4.jpg', '4 L : 4 COLOURS ', 'liquids detergents');
INSERT INTO products VALUES ('27', 'SOYABEAN MEAL', 'It is pure fine and homogeneous meal, free of any lumps , insects , aflatoxins or extraneous matters . it is used in the manufacturing of the cattle fodder , &poultry fodder .it is a rich source of protein .', 'images/portfolio/Animals_Feeds/096.jpg', null, 'animals feeds');
INSERT INTO products VALUES ('28', 'CATTLE FODDER', 'It is a mixture of the highest qualities of meals, corn, bran, mineral salt & vitamins - Cylinders of diameter bet . 8 mm & 16 mm.', 'images/portfolio/No-Image.jpg', null, 'animals feeds');
INSERT INTO products VALUES ('29', 'COTTON SEED MEAL', 'It is pure fine and homogeneous meal, free of any lumps, insects, aflatoxins or extraneous matter . high in protein 24% min .', 'images/portfolio/No-Image.jpg', null, 'animals feeds');
INSERT INTO products VALUES ('30', 'ROSA automatic powder', 'Safe on washing machine </br> Removes tough stains </br> A pleasant aroma', 'images/portfolio/new_products/rosa.jpg', '1kilo', 'new products');
INSERT INTO products VALUES ('31', 'Sofia ', 'toilet soap', 'images/portfolio/No-Image.jpg', '4color * 150gm', 'new products');
INSERT INTO products VALUES ('32', 'Astra ', 'toilet soap', 'images/portfolio/No-Image.jpg', '4color * 150gm', 'new products');

-- ----------------------------
-- Table structure for `suppliers`
-- ----------------------------
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `attach_file` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of suppliers
-- ----------------------------
INSERT INTO suppliers VALUES ('1', '', '', '', '');
INSERT INTO suppliers VALUES ('2', '', '', '', '');
INSERT INTO suppliers VALUES ('3', '', '', '', '');
